function agendarClase() {
  window.open("https://wa.me/593XXXXXXXXX?text=Hola,%20quiero%20agendar%20una%20clase%20en%20PRIVATE%20CLASSES", "_blank");
}